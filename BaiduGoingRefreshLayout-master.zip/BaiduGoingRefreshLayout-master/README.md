# BaiduGoingRefreshLayout
Android自定义下拉刷新动画--仿百度外卖下拉刷新

<img src="http://img.blog.csdn.net/20160411115612150" width = "320" height = "640" alt="高仿微信群聊头像" align=center />
